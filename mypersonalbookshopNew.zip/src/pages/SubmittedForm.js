import React from 'react';

const SubmittedForm = () => {
  return (
      <div>
        <p>Thank you for submitting your details</p>
      </div>
  )
}

console.log(SubmittedForm)

export default SubmittedForm
