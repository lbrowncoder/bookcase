import {Link, NavLink} from 'react-router-dom';
import React from 'react';
import './HomePage.css';

function HomePage() {
    return (
        <React.Fragment>  
                <a href="/pages/Search"><h1 className='title'>Welcome to Your Bookcase</h1></a>
                <p className='homeP'>Search, Share, Buy</p>
                {/* <a href="/pages/Search"><button className='homeBtn'> Enter </button></a> */}

        </React.Fragment>    
    )
}


export default HomePage