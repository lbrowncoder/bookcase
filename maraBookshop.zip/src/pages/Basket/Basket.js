import React from 'react';

// I have just started working on this#

const Basket = () => {
    return (
        <div >
          <p>Basket Is empty</p>
        </div>
    )
  }
  
  export default Basket