import React from 'react';
import '../Contact/Contact.css';

const SubmittedForm = () => {
  return (
      <div className='thankYou'>
        <p>Thank you for submitting your details.</p>
      </div>
  )
}

console.log(SubmittedForm)

export default SubmittedForm
