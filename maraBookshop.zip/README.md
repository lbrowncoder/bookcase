Bookcase

On this module we focused on building an interactive bookcase using JavaScript and React.

With this bookcase App you can search for your favorite book and store it in your own personal bookcase.

Languages Used:

HTML
JavaScript
CSS
React
